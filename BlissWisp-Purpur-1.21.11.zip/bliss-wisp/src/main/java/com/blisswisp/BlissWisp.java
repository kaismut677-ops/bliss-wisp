package com.blisswisp;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class BlissWisp extends JavaPlugin {
    private BukkitTask task;
    private Location origin;
    private double angle;
    private double rise;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        PluginCommand command = getCommand("wisp");
        if (command != null) command.setExecutor(this::onCommand);
        getLogger().info("BlissWisp enabled.");
    }

    @Override
    public void onDisable() {
        stopWisp();
    }

    private boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only a player can use this command.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("stop")) {
            stopWisp();
            player.sendMessage("§bWisp stopped.");
            return true;
        }
        if (task != null) {
            stopWisp();
            player.sendMessage("§bWisp stopped.");
            return true;
        }
        origin = player.getLocation().clone().add(0, 1.2, 0);
        angle = 0;
        rise = 0;
        startWisp();
        player.sendMessage("§bWisp spawned.");
        return true;
    }

    private void startWisp() {
        final int arms = getConfig().getInt("arms", 10);
        final int points = getConfig().getInt("points-per-arm", 11);
        final double radius = getConfig().getDouble("radius", 3.9);
        final double armHeight = getConfig().getDouble("arm-height", 1.15);
        final double rotationSpeed = getConfig().getDouble("rotation-speed", 0.075);
        final double riseSpeed = getConfig().getDouble("rise-speed", 0.012);
        final double jitter = getConfig().getDouble("jitter", 0.10);
        final double soulChance = getConfig().getDouble("soul-chance", 0.72);
        final double sparkChance = getConfig().getDouble("spark-chance", 0.12);
        final double sparkRadius = getConfig().getDouble("spark-radius", 4.6);
        final boolean centerSmoke = getConfig().getBoolean("center-smoke", true);

        task = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (origin == null || origin.getWorld() == null) {
                stopWisp();
                return;
            }
            World world = origin.getWorld();
            ThreadLocalRandom r = ThreadLocalRandom.current();

            // The screenshot's dark, dense middle.
            if (centerSmoke) {
                world.spawnParticle(Particle.SMOKE, origin.clone().add(0, 0.2 + r.nextDouble(-0.15, 0.15), 0),
                        4, 0.35, 0.25, 0.35, 0.01);
                world.spawnParticle(Particle.SOUL, origin.clone().add(0, 0.1, 0),
                        3, 0.45, 0.35, 0.45, 0.01);
            }

            // Ten long, uneven spiral tendrils.
            for (int arm = 0; arm < arms; arm++) {
                double armBase = (Math.PI * 2.0 * arm) / arms;
                double wobble = Math.sin(angle * 1.7 + arm * 2.1) * 0.10;
                for (int i = 0; i < points; i++) {
                    double t = i / (double) (points - 1);
                    double a = armBase + angle + t * 2.05 + wobble;
                    // Pull the inner part toward the center and flare the outer part.
                    double rr = 0.35 + radius * Math.pow(t, 0.78);
                    rr += Math.sin(t * 9.0 + arm * 1.7 + angle * 2.0) * 0.20;

                    double x = Math.cos(a) * rr;
                    double z = Math.sin(a) * rr;
                    double y = armHeight * Math.sin(t * Math.PI * 1.15 + arm * 0.37 + angle * 0.8)
                            + t * 0.25;

                    // Make the tendrils slightly chaotic instead of perfect mathematical lines.
                    x += r.nextDouble(-jitter, jitter);
                    y += r.nextDouble(-jitter, jitter);
                    z += r.nextDouble(-jitter, jitter);

                    Location p = origin.clone().add(x, y, z);
                    if (r.nextDouble() < soulChance) {
                        world.spawnParticle(Particle.SOUL_FIRE_FLAME, p, 1, 0, 0, 0, 0);
                    } else {
                        world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
                    }

                    // Cyan dust gives the bright halo visible in the reference.
                    if (r.nextDouble() < 0.32) {
                        Particle.DustOptions dust = new Particle.DustOptions(
                                Color.fromRGB(70, 245, 255),
                                (float) r.nextDouble(0.65, 1.25));
                        world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, dust);
                    }
                }
            }

            // Loose particles around the outside, matching the scattered look.
            for (int i = 0; i < 18; i++) {
                if (r.nextDouble() > sparkChance + 0.22) continue;
                double a = r.nextDouble(0, Math.PI * 2);
                double rr = r.nextDouble(radius * 0.85, sparkRadius);
                double x = Math.cos(a) * rr;
                double z = Math.sin(a) * rr;
                double y = r.nextDouble(-1.4, 2.3);
                Location p = origin.clone().add(x, y, z);
                world.spawnParticle(r.nextBoolean() ? Particle.SOUL_FIRE_FLAME : Particle.END_ROD,
                        p, 1, 0, 0, 0, 0);
            }

            angle += rotationSpeed;
            rise += riseSpeed;
            // Slowly move the whole effect upward, then reset it for a looping soul-like drift.
            if (rise >= 2.2) {
                rise = 0;
                origin.setY(origin.getY() - 2.2);
            } else {
                origin.setY(origin.getY() + riseSpeed);
            }
        }, 0L, 1L);
    }

    private void stopWisp() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        origin = null;
    }
}
